namespace AsyncTryoutDemo.AsyncDemo;

public class AsyncHttpClient
{
    public static async Task DemoAsyncHttpClientWithoutBlocking()
    {
        var response1 = await FetchDataAsync("http://localhost:8001/Product/GetProductById/1");
        var response2 = await FetchDataAsync("http://localhost:8001/Product/GetProducts");

        Console.WriteLine($"Response 1: {response1}");
        Console.WriteLine($"Response 2: {response2}");

        Console.WriteLine("All requests completed.");
    }
    
    
    public static void DemoAsyncHttpClientWithLazyInit()
    {
        var response1 = new Lazy<Task<string>>(() => FetchDataAsync("http://localhost:8001/Product/GetProductById/1"));
        var response2 = new Lazy<Task<string>>(() =>FetchDataAsync("http://localhost:8001/Product/GetProducts"));

        Console.WriteLine($"Response 1: {response1.Value.Result}");
        Console.WriteLine($"Response 2: {response2.Value.Result}");

        Console.WriteLine("All requests completed.");
    }
    

    public static async Task DemoAsyncHttpCallAsync()
    {
        // Make asynchronous HTTP requests
        var response1 = FetchDataAsync("http://localhost:8001/Product/GetProductById/1");
        var response2 = FetchDataAsync("http://localhost:8001/Product/GetProducts");

        var firstCompletedTask = await Task.WhenAny(response1, response2);

        Console.WriteLine($"Response: {await firstCompletedTask}");

        // Print the result of the other response
        var remainingTask = firstCompletedTask == response1 ? response2 : response1;
        Console.WriteLine($"Response: {await remainingTask}");

        Console.WriteLine("All requests completed.");
    }


    private static async Task<string> FetchDataAsync(string url)
    {
        using var client = new HttpClient();
        var response = await client.GetAsync(url);
        response.EnsureSuccessStatusCode();

        return await response.Content.ReadAsStringAsync();
    }
}