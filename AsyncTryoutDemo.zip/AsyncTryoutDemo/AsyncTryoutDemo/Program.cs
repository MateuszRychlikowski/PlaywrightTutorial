﻿using AsyncTryoutDemo.AsyncDemo;

Console.WriteLine("Perform Calls ....");

//SyncWebClient.DemoSyncHttpClient();

//SyncWebClient.DemoSyncHttpClientWithTask();

//SyncWebClient.DemoSyncHttpCallWithTaskWithoutAsync();

//await SyncWebClient.DemoSyncHttpCallWithTaskWithAsync();

//await AsyncHttpClient.DemoAsyncHttpClientWithoutBlocking();

//await AsyncHttpClient.DemoAsyncHttpCallAsync();

AsyncHttpClient.DemoAsyncHttpClientWithLazyInit();