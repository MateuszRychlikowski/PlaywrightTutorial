using System.Net;

namespace AsyncTryoutDemo.SyncDemo;

public class SyncWebClient
{
    public static void DemoSyncHttpClient()
    {
        //Make Synchronous calls
        var response1 = FetchData("http://localhost:8001/Product/GetProductById/1");
        var response2 = FetchData("http://localhost:8001/Product/GetProducts");

        Console.WriteLine($"Response 1: {response1}");
        Console.WriteLine($"Response 2: {response2}");

        Console.WriteLine("All requests completed.");
    }

    public static void DemoSyncHttpClientWithTask()
    {
        //Make Synchronous calls
        var response1 = Task.Run(() => FetchData("http://localhost:8001/Product/GetProductById/1"));
        var response2 = Task.Run(() => FetchData("http://localhost:8001/Product/GetProducts"));

        response1.Wait();
        response2.Wait();

        Console.WriteLine($"Response 1: {response1.Result}");
        Console.WriteLine($"Response 2: {response2.Result}");

        Console.WriteLine("All requests completed.");
    }

    public static void DemoSyncHttpCallWithTaskWithoutAsync()
    {
        // Make asynchronous HTTP requests
        var response1 = Task.Run(() => FetchData("http://localhost:8001/Product/GetProductById/1"));
        var response2 = Task.Run(() => FetchData("http://localhost:8001/Product/GetProducts"));


        var continuationTask = Task.WhenAny(response1, response2).ContinueWith(completedTask =>
        {
            var completedResponse = completedTask.Result;
            Console.WriteLine($"Response: {completedResponse.Result}");

            // Print the result of the other response
            var remainingTask = completedResponse == response1 ? response2 : response1;
            Console.WriteLine($"Response: {remainingTask.Result}");

            Console.WriteLine("All requests completed.");
        });

        // Wait for the continuation task to complete
        continuationTask.Wait();
    }

    public static async Task DemoSyncHttpCallWithTaskWithAsync()
    {
        // Make asynchronous HTTP requests
        var response1 = Task.Run(() => FetchData("http://localhost:8001/Product/GetProductById/1"));
        var response2 = Task.Run(() => FetchData("http://localhost:8001/Product/GetProducts"));

        var firstCompletedTask = await Task.WhenAny(response1, response2);

        Console.WriteLine($"Response: {await firstCompletedTask}");

        // Print the result of the other response
        var remainingTask = firstCompletedTask == response1 ? response2 : response1;
        Console.WriteLine($"Response: {await remainingTask}");

        Console.WriteLine("All requests completed.");
    }


    public static string FetchData(string url)
    {
        using var webClient = new WebClient();
        try
        {
            return webClient.DownloadString(url);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
            return null;
        }
    }
}